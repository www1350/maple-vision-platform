# Offline FailureBundle

Recorded outcome: **failed**. Reason: `combat_progress_timeout`.

This bundle contains 70 actually applied actions and 71 frames, including the real terminal observation. Termination cause: `policy`. Successful runs are also supported.

## Verification boundary

The default verifier checks source-run integrity, replays actual applied actions, reconstructs deterministic simulator states and exact capture RGB pixels, and reprojects every derived layer. Requested actions do not advance ground truth.

Observations, temporal beliefs, tasks, visual-effect verdicts and supervisor decisions are faithfully copied recorded evidence. Their perception and policy have **not been re-executed by default**. Use `verify_failure_bundle(..., reinfer=True)` to actually rerun all N+1 frames with the matching local detector/settings. The returned report describes that invocation; no archived success flag substitutes for execution.

The optional MP4 is lossy display material. Its container, sample timeline and hashes are checked separately; `video.semantic_reproduction` is false. Authoritative pixels are the reconstructed RGB hashes and lossless PNG frames. Matching a display hash is not proof of exact source pixels or a proof against a completely re-authored video plus manifest. No permissive pixel threshold is called exact agreement.

## Scope and provenance

Everything here concerns the independent offline synthetic simulator. It does not establish official-client behavior, real-domain model accuracy, account safety, or a 24-hour wall-clock soak. Asset provenance remains in source-run sidecars.

`source-run/` is an exact private copy. Original source paths are unnecessary for action/RGB replay. Optional model reinference still needs the exact local model. Checksums bind content and detect inconsistency; they are not a digital signature of the original author. `config.yaml` is JSON, a YAML 1.2 subset.
